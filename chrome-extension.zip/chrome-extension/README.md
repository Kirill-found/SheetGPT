# SheetGPT Chrome Extension

AI-powered assistant for Google Sheets - analyze data, create tables, and generate insights.

## 🚀 Features

- **AI Chat Interface** - sidebar with chat для работы с данными
- **Auto Data Reading** - автоматически читает данные из активного листа
- **Smart Analysis** - топ товаров, средние значения, фильтрация
- **Table Generation** - создание таблиц из AI знаний (страны, города и т.д.)
- **Easy Integration** - работает прямо в Google Sheets

## 📦 Installation (Local Development)

1. Откройте Chrome и перейдите в `chrome://extensions/`
2. Включите "Developer mode" (переключатель в правом верхнем углу)
3. Нажмите "Load unpacked"
4. Выберите папку `chrome-extension`
5. Готово! Расширение установлено

## 🎨 Icons

Иконки нужно разместить в папке `icons/`:
- `icon16.png` - 16x16px
- `icon48.png` - 48x48px
- `icon128.png` - 128x128px

Можно создать простые иконки с логотипом SheetGPT или использовать https://www.canva.com для дизайна.

## 🔧 How to Use

1. Откройте Google Sheets
2. Нажмите на синюю кнопку справа (или кликните на иконку расширения)
3. Sidebar откроется справа
4. Выделите данные (или оставьте пустым для генерации таблиц)
5. Задайте вопрос в чате
6. Получите результат!

## 📝 Example Queries

### С данными:
- "Найди топ 3 товара по продажам"
- "Посчитай среднюю выручку"
- "Выдели строки где сумма меньше 100 тысяч"
- "Объедини ФИО в одну ячейку"

### Без данных (AI генерация):
- "Создай таблицу со странами Европы и их населением"
- "Список крупнейших городов России"
- "Планеты солнечной системы"

## 🔗 API Backend

Extension использует SheetGPT API:
- **Production:** https://sheetgpt-production.up.railway.app
- **Version:** 7.3.1
- **Endpoint:** /api/v1/formula

## 📋 TODO

- [ ] Реализовать чтение данных из Google Sheets через Sheets API
- [ ] Добавить запись результатов обратно в лист
- [ ] Добавить поддержку выделения строк (highlighting)
- [ ] Сохранение истории запросов
- [ ] Настройки (API key для premium функций)
- [ ] Экспорт результатов в PDF/CSV

## 🚀 Publishing to Chrome Web Store

1. Создайте zip архив папки `chrome-extension`
2. Зарегистрируйтесь на https://chrome.google.com/webstore/devconsole ($5 разовая оплата)
3. Загрузите zip архив
4. Заполните описание, скриншоты, категории
5. Отправьте на модерацию (1-3 дня)

## 📄 License

MIT License - свободное использование

## 🤝 Support

Вопросы и предложения: создайте issue в репозитории
