/**
 * SheetGPT Popup Script
 */

const API_URL = 'https://sheetgpt-production.up.railway.app';

// Elements
const sheetsContent = document.getElementById('sheetsContent');
const notSheetsContent = document.getElementById('notSheetsContent');
const statusBanner = document.getElementById('statusBanner');
const openSidebarBtn = document.getElementById('openSidebarBtn');
const testConnectionBtn = document.getElementById('testConnectionBtn');
const openSheetsBtn = document.getElementById('openSheetsBtn');
const themeToggle = document.getElementById('themeToggle');

// Initialize
document.addEventListener('DOMContentLoaded', init);

async function init() {
  loadTheme();
  setupEventListeners();
  await checkCurrentTab();
}

function loadTheme() {
  const theme = localStorage.getItem('sheetgpt_theme') || 'dark';
  document.body.setAttribute('data-theme', theme);
}

function setupEventListeners() {
  themeToggle.addEventListener('click', toggleTheme);
  openSidebarBtn.addEventListener('click', openSidebar);
  testConnectionBtn.addEventListener('click', testConnection);
  openSheetsBtn.addEventListener('click', openGoogleSheets);
}

function toggleTheme() {
  const current = document.body.getAttribute('data-theme');
  const newTheme = current === 'dark' ? 'light' : 'dark';
  document.body.setAttribute('data-theme', newTheme);
  localStorage.setItem('sheetgpt_theme', newTheme);
}

async function checkCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab && tab.url && tab.url.includes('docs.google.com/spreadsheets')) {
      sheetsContent.classList.remove('hidden');
      notSheetsContent.classList.add('hidden');
    } else {
      sheetsContent.classList.add('hidden');
      notSheetsContent.classList.remove('hidden');
    }
  } catch (error) {
    console.error('Error checking tab:', error);
    sheetsContent.classList.add('hidden');
    notSheetsContent.classList.remove('hidden');
  }
}

async function openSidebar() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (tab && tab.id) {
      await chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_SIDEBAR' });
      window.close();
    }
  } catch (error) {
    console.error('Error opening sidebar:', error);
    showStatus('Ошибка. Перезагрузите страницу.', 'error');
  }
}

async function testConnection() {
  testConnectionBtn.disabled = true;
  testConnectionBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation: spin 1s linear infinite">
      <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
    </svg>
    Проверка...
  `;
  
  try {
    const response = await fetch(`${API_URL}/api/health`, {
      method: 'GET',
      timeout: 5000
    });
    
    if (response.ok) {
      showStatus('Соединение установлено', 'success');
    } else {
      showStatus('Сервер недоступен', 'error');
    }
  } catch (error) {
    showStatus('Ошибка соединения', 'error');
  }
  
  testConnectionBtn.disabled = false;
  testConnectionBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <path d="M5 12h14M12 5l7 7-7 7"/>
    </svg>
    Проверить соединение
  `;
}

function showStatus(message, type) {
  statusBanner.className = `status-banner ${type}`;
  statusBanner.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      ${type === 'success' 
        ? '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>'
        : '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>'
      }
    </svg>
    <span>${message}</span>
  `;
}

function openGoogleSheets() {
  chrome.tabs.create({ url: 'https://docs.google.com/spreadsheets' });
  window.close();
}

// Add spin animation
const style = document.createElement('style');
style.textContent = `
  @keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
`;
document.head.appendChild(style);
