/**
 * SheetGPT Content Script
 * Injects sidebar into Google Sheets
 */

(function() {
  'use strict';

  // Prevent multiple injections
  if (window.__sheetGPTInjected) return;
  window.__sheetGPTInjected = true;

  const SIDEBAR_WIDTH = 360;
  
  let sidebar = null;
  let toggleButton = null;
  let isOpen = false;
  let isContextValid = true;

  // Check extension context
  function checkExtensionContext() {
    try {
      chrome.runtime.getURL('');
      return true;
    } catch (e) {
      return false;
    }
  }

  // Initialize
  function init() {
    if (!checkExtensionContext()) {
      console.warn('SheetGPT: Extension context invalid');
      isContextValid = false;
      return;
    }
    
    createToggleButton();
    createSidebar();
    setupMessageListeners();
    
    console.log('SheetGPT: Initialized');
  }

  // Create toggle button
  function createToggleButton() {
    toggleButton = document.createElement('button');
    toggleButton.id = 'sheetgpt-toggle';
    toggleButton.title = 'Открыть SheetGPT';
    toggleButton.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <line x1="3" y1="9" x2="21" y2="9"/>
        <line x1="9" y1="3" x2="9" y2="21"/>
      </svg>
    `;
    
    const styles = `
      #sheetgpt-toggle {
        position: fixed;
        right: 16px;
        top: 50%;
        transform: translateY(-50%);
        z-index: 9999;
        width: 44px;
        height: 44px;
        background: #6840ff;
        border: 2px solid #a1ff62;
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 12px rgba(104, 64, 255, 0.4);
        transition: all 0.2s ease;
      }
      
      #sheetgpt-toggle:hover {
        transform: translateY(-50%) scale(1.05);
        box-shadow: 0 6px 16px rgba(104, 64, 255, 0.5);
      }
      
      #sheetgpt-toggle:active {
        transform: translateY(-50%) scale(0.95);
      }
      
      #sheetgpt-toggle svg {
        width: 20px;
        height: 20px;
        color: #a1ff62;
      }
      
      #sheetgpt-toggle.open {
        right: ${SIDEBAR_WIDTH + 16}px;
      }
      
      #sheetgpt-sidebar {
        position: fixed;
        top: 0;
        right: -${SIDEBAR_WIDTH}px;
        width: ${SIDEBAR_WIDTH}px;
        height: 100vh;
        z-index: 9998;
        background: #0d0d12;
        border-left: 1px solid rgba(161, 255, 98, 0.2);
        box-shadow: -4px 0 24px rgba(0, 0, 0, 0.3);
        transition: right 0.3s cubic-bezier(0.4, 0, 0.2, 1);
      }
      
      #sheetgpt-sidebar.open {
        right: 0;
      }
      
      #sheetgpt-sidebar iframe {
        width: 100%;
        height: 100%;
        border: none;
      }
      
      #sheetgpt-reload-banner {
        position: fixed;
        top: 16px;
        right: 16px;
        z-index: 10000;
        background: #1a1a21;
        border: 1px solid #f87171;
        border-radius: 8px;
        padding: 12px 16px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 13px;
        color: #f5f5f7;
        display: flex;
        align-items: center;
        gap: 12px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
      }
      
      #sheetgpt-reload-banner button {
        background: #a1ff62;
        border: none;
        border-radius: 4px;
        padding: 6px 12px;
        font-size: 12px;
        font-weight: 600;
        color: #0d0d12;
        cursor: pointer;
      }
      
      #sheetgpt-reload-banner button:hover {
        background: #8ce854;
      }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);
    
    toggleButton.addEventListener('click', toggleSidebar);
    document.body.appendChild(toggleButton);
  }

  // Create sidebar
  function createSidebar() {
    sidebar = document.createElement('div');
    sidebar.id = 'sheetgpt-sidebar';
    
    const iframe = document.createElement('iframe');
    iframe.src = chrome.runtime.getURL('src/sidebar.html');
    iframe.allow = 'clipboard-write';
    
    sidebar.appendChild(iframe);
    document.body.appendChild(sidebar);
  }

  // Toggle sidebar
  function toggleSidebar() {
    if (!isContextValid) {
      showReloadBanner();
      return;
    }
    
    isOpen = !isOpen;
    sidebar.classList.toggle('open', isOpen);
    toggleButton.classList.toggle('open', isOpen);
    toggleButton.title = isOpen ? 'Закрыть SheetGPT' : 'Открыть SheetGPT';
  }

  // Show reload banner
  function showReloadBanner() {
    if (document.getElementById('sheetgpt-reload-banner')) return;
    
    const banner = document.createElement('div');
    banner.id = 'sheetgpt-reload-banner';
    banner.innerHTML = `
      <span>Расширение обновлено. Перезагрузите страницу.</span>
      <button onclick="location.reload()">Перезагрузить</button>
    `;
    document.body.appendChild(banner);
  }

  // Setup message listeners
  function setupMessageListeners() {
    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      if (message.type === 'TOGGLE_SIDEBAR') {
        toggleSidebar();
        sendResponse({ success: true });
      }
      return true;
    });

    // Listen for messages from iframe
    window.addEventListener('message', async (event) => {
      if (!event.data || !event.data.type) return;
      
      const { type, ...data } = event.data;
      
      try {
        let result;
        
        switch (type) {
          case 'GET_SHEET_DATA':
            result = await getSheetData();
            postToSidebar({ type: 'SHEET_DATA', data: result });
            break;
            
          case 'INSERT_FORMULA':
            result = await insertFormula(data.formula);
            postToSidebar({ type: 'INSERT_RESULT', success: result });
            break;
            
          case 'INSERT_TABLE':
            result = await insertTable(data.tableData);
            postToSidebar({ type: 'INSERT_RESULT', success: result });
            break;
            
          case 'HIGHLIGHT_ROWS':
            result = await highlightRows(data.rows, data.color);
            postToSidebar({ type: 'HIGHLIGHT_RESULT', success: result });
            break;
        }
      } catch (error) {
        console.error('SheetGPT error:', error);
        postToSidebar({ type: 'ERROR', error: error.message });
      }
    });
  }

  // Post message to sidebar iframe
  function postToSidebar(message) {
    const iframe = sidebar?.querySelector('iframe');
    if (iframe?.contentWindow) {
      iframe.contentWindow.postMessage(message, '*');
    }
  }

  // Get sheet data via background script
  async function getSheetData() {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'GET_SHEET_DATA' }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response?.data || null);
        }
      });
    });
  }

  // Insert formula
  async function insertFormula(formula) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'INSERT_FORMULA', formula }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response?.success || false);
        }
      });
    });
  }

  // Insert table
  async function insertTable(tableData) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'INSERT_TABLE', tableData }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response?.success || false);
        }
      });
    });
  }

  // Highlight rows
  async function highlightRows(rows, color) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'HIGHLIGHT_ROWS', rows, color }, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
        } else {
          resolve(response?.success || false);
        }
      });
    });
  }

  // Keyboard shortcut
  document.addEventListener('keydown', (e) => {
    if (e.altKey && e.key.toLowerCase() === 's') {
      e.preventDefault();
      toggleSidebar();
    }
  });

  // Initialize when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
