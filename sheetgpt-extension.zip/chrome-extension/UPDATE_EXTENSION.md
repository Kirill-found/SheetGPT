# Обновление Chrome Extension (КРИТИЧЕСКОЕ ИСПРАВЛЕНИЕ)

## Что было исправлено

**Проблема**: Расширение показывало сообщение "Выделено строк: 2", но фактически **НЕ применяло подсветку** к Google Sheets.

**Корневая причина**: Функция `displayResult()` только показывала сообщение, но **не вызывала** функцию `highlightRows()`.

**Исправление**: Добавлен фактический вызов `highlightRows()` в `displayResult()`.

---

## Шаги обновления

### 1. Обновите код расширения
```bash
cd C:\SheetGPT\chrome-extension
git pull origin main
```

### 2. Перезагрузите расширение в Chrome

1. Откройте: `chrome://extensions/`
2. Найдите **SheetGPT AI Assistant**
3. Нажмите кнопку **🔄 Reload** (обновить)

### 3. Обновите страницу Google Sheets

1. Откройте вашу таблицу
2. Нажмите **F5** или **Ctrl+R** для обновления страницы

---

## Проверка работы

1. Откройте расширение (синяя кнопка справа)
2. Введите запрос: **"выдели города с населением больше 1,7 млн"**
3. Нажмите **Enter**

**Ожидаемый результат**:
- ✅ Backend вернёт: `highlight_rows: [2, 3]`
- ✅ Расширение покажет: "✅ Выделено строк: 2, 3"
- ✅ В Google Sheets строки 2-3 будут выделены **жёлтым цветом**

---

## Полный список исправлений (v6.6.9)

1. ✅ **Backend**: Исправлен парсинг чисел с запятыми ("12,6" → 12.6)
2. ✅ **Backend**: Обновлён OpenAI до 1.109.1 (совместимость с httpx 0.28.1)
3. ✅ **Extension**: Исправлена конвертация индексов строк (1-based → 0-based)
4. ✅ **Extension**: Исправлен путь импорта `sheets-api.js`
5. ✅ **Extension**: Добавлено чтение данных из DOM (без OAuth timeout)
6. ✅ **Extension**: **КРИТИЧЕСКОЕ** - Добавлен вызов `highlightRows()` в `displayResult()`

---

## Если подсветка не работает

### Проверка 1: Консоль расширения (service worker)
1. `chrome://extensions/` → **SheetGPT** → **"Проверить представления: service worker"**
2. В консоли должно быть:
   ```
   [Background] Service worker started
   [SheetsAPI] ✅ Got auth token
   ```

### Проверка 2: Консоль Google Sheets (F12)
1. Откройте DevTools (F12)
2. В консоли должны быть логи:
   ```javascript
   [SheetGPT] Content script loaded
   [SheetGPT] Reading data from DOM...
   [SheetGPT] ✅ Read from DOM: 10 rows, 2 columns
   [SheetGPT] Applying highlight to rows: [2, 3]
   [SheetGPT] ✅ Rows highlighted
   ```

### Проверка 3: OAuth авторизация
Если видите ошибку "Auth error", выполните в консоли service worker:
```javascript
chrome.identity.getAuthToken({ interactive: true }, (token) => {
  console.log('Token:', token ? 'OK' : 'Missing');
});
```

---

## Коммиты

- `74f2b4c` - Fix: Actually call highlightRows() when result contains highlight_rows
- `0accdd8` - Fix: Read sheet data from DOM instead of OAuth API
- `4281b99` - Fix: Correct importScripts path for sheets-api.js
- `9657f1f` - Fix: Correct row index conversion for highlight
- `a97bd23` - Fix: Handle comma decimal separators in numeric comparisons

---

## Поддержка

Если после всех шагов подсветка НЕ работает:
1. Откройте DevTools (F12) на странице Google Sheets
2. Скопируйте всё из вкладки Console
3. Откройте `chrome://extensions/` → SheetGPT → "service worker" → скопируйте console
4. Отправьте оба лога для анализа
